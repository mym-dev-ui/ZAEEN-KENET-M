# Standalone Payment UI

واجهة مستقلة مبنية بـ `HTML` و `CSS` و `JavaScript` فقط، بدون أي مشروع أو مكتبة موجودة مسبقًا.

## التشغيل المحلي

افتح الملف `index.html` مباشرة، أو شغّل خادمًا بسيطًا:

```bash
cd /Users/macbook/standalone-payment-ui
python3 -m http.server 4173
```

ثم افتح:

`http://localhost:4173`

## الملفات

- `index.html`: هيكل الصفحة
- `styles.css`: التنسيق الكامل
- `script.js`: تفاعل القائمة المنسدلة
