const trigger = document.getElementById("bank-trigger");
const dropdown = document.getElementById("bankDropdown");
const selectedDigits = document.getElementById("selectedDigits");
const selectedLogo = document.getElementById("selectedLogo");
const options = Array.from(document.querySelectorAll(".bank-option"));

function closeDropdown() {
  dropdown.hidden = true;
  trigger.setAttribute("aria-expanded", "false");
}

function openDropdown() {
  dropdown.hidden = false;
  trigger.setAttribute("aria-expanded", "true");
}

function swapLogo(bank) {
  if (bank === "BBK") {
    selectedLogo.className = "brand brand--bbk brand--compact";
    selectedLogo.innerHTML = `
      <span class="brand__name">BBK</span>
      <span class="brand__sun"></span>
    `;
    return;
  }

  selectedLogo.className = "brand brand--abk brand--compact";
  selectedLogo.innerHTML = `
    <span class="brand__arabic">البنك</span>
    <span class="brand__name">ABK</span>
    <span class="brand__link"></span>
  `;
}

trigger.addEventListener("click", () => {
  if (dropdown.hidden) {
    openDropdown();
  } else {
    closeDropdown();
  }
});

options.forEach((option) => {
  option.addEventListener("click", () => {
    options.forEach((item) => item.classList.remove("is-active"));
    option.classList.add("is-active");

    selectedDigits.textContent = option.dataset.digits.replace(/(\d{4})(\d{2})/, "$1 $2");
    swapLogo(option.dataset.bank);
    closeDropdown();
  });
});

document.addEventListener("click", (event) => {
  if (!event.target.closest(".bank-select")) {
    closeDropdown();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeDropdown();
  }
});
